from django.apps import AppConfig


class AppManagementConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'app_management'
